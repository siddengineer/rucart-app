import os
import zipfile

zip_filename = r'c:\Users\K\Downloads\rucart_app.zip'
source_dir = r'c:\Users\K\Downloads\rucart app'

exclude_dirs = {
    '.git', '.gradle', 'build', 'target', '.idea', '.vscode', '.settings',
    'bin', '.system_generated', '__pycache__'
}

exclude_extensions = {
    '.class', '.pyc', '.pyo'
}

count = 0
print(f"Creating zip file: {zip_filename}...")
with zipfile.ZipFile(zip_filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
    for root, dirs, files in os.walk(source_dir):
        # Filter directories in-place
        dirs[:] = [d for d in dirs if d not in exclude_dirs]
        
        for file in files:
            ext = os.path.splitext(file)[1].lower()
            if ext in exclude_extensions:
                continue
            if file == 'rucart_app.zip':
                continue
                
            full_path = os.path.join(root, file)
            rel_path = os.path.relpath(full_path, source_dir)
            
            # Avoid putting zip in itself or temporary artifacts
            if 'rucart_app.zip' in rel_path:
                continue
                
            zipf.write(full_path, arcname=rel_path)
            count += 1

size_mb = os.path.getsize(zip_filename) / (1024 * 1024)
print(f"Successfully zipped {count} files! Total size: {size_mb:.2f} MB")
